<?php
include 'koneksi.php';
session_start();

if (!isset($_SESSION['username']) || $_SESSION['level'] != 'Admin') {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action'])) {
    if ($_POST['action'] == 'update_status') {
        $order_id = $_POST['order_id'];
        $status = $_POST['status'];

        $query = "UPDATE `order` SET status='$status' WHERE id='$order_id'";
        mysqli_query($koneksi, $query);
        echo "<script>alert('Status pesanan berhasil diubah'); window.location.href = 'manage_orders.php';</script>";
    }
}

$query = "SELECT o.id, o.order_date, o.status, r.username, pm.method, p.amount 
          FROM `order` o 
          JOIN payment p ON o.id = p.order_id 
          JOIN payment_method pm ON p.payment_method_id = pm.id
          JOIN register r ON o.username = r.username";
$result = mysqli_query($koneksi, $query);

if (!$result) {
    die('Query Error: ' . mysqli_error($koneksi));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Pesanan</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, rgba(58,123,213,1) 0%, rgba(58,213,173,1) 100%);
            font-family: 'Roboto', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }
        .container {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            max-width: 1000px;
            width: 100%;
        }
        .form-group label {
            font-weight: bold;
            color: #333;
        }
        .btn-primary {
            background-color: #3A7BD5;
            border-color: #3A7BD5;
        }
        .btn-primary:hover {
            background-color: #2E5BA2;
            border-color: #2E5BA2;
        }
        .btn-secondary {
            background-color: #3AD5AD;
            border-color: #3AD5AD;
        }
        .btn-secondary:hover {
            background-color: #2EA283;
            border-color: #2EA283;
        }
        .btn-warning {
            background-color: #ff9800;
            border-color: #ff9800;
            color: #fff;
        }
        .btn-warning:hover {
            background-color: #e68900;
            border-color: #e68900;
            color: #fff;
        }
        .table th, .table td {
            vertical-align: middle;
            text-align: center;
            border: 2px solid #dee2e6;
        }
        .table th {
            background-color: #3A7BD5;
            color: #fff;
        }
        h2 {
            color: #3A7BD5;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h2>Kelola Pesanan</h2>
            <a href="home_admin.php" class="btn btn-secondary">Kembali ke Home Admin</a>
        </div>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID Pesanan</th>
                    <th>Tanggal</th>
                    <th>Status</th>
                    <th>Pengguna</th>
                    <th>Metode Pembayaran</th>
                    <th>Jumlah</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['order_date']; ?></td>
                        <td><?php echo $row['status']; ?></td>
                        <td><?php echo $row['username']; ?></td>
                        <td><?php echo $row['method']; ?></td>
                        <td><?php echo $row['amount']; ?></td>
                        <td>
                            <form method="post" action="">
                                <input type="hidden" name="order_id" value="<?php echo $row['id']; ?>">
                                <input type="hidden" name="action" value="update_status">
                                <select name="status" class="form-control mb-2">
                                    <option value="Pending" <?php echo $row['status'] == 'Pending' ? 'selected' : ''; ?>>Pending</option>
                                    <option value="Confirmed" <?php echo $row['status'] == 'Confirmed' ? 'selected' : ''; ?>>Confirmed</option>
                                    <option value="Cancelled" <?php echo $row['status'] == 'Cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                </select>
                                <button type="submit" class="btn btn-warning">Ubah Status</button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>
