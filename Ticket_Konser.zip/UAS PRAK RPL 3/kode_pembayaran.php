<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$kode_pembayaran = $_GET['kode'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kode Pembayaran</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Kode Pembayaran</h2>
        <p>Kode Pembayaran Anda adalah:</p>
        <h3><?php echo $kode_pembayaran; ?></h3>
        <a href="home_user.php" class="btn btn-primary mt-3">Kembali ke Halaman Utama</a>
    </div>
</body>
</html>
