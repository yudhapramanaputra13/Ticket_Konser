<?php
session_start();
include('koneksi.php');

if (!isset($_SESSION['username']) || $_SESSION['level'] != 'User') {
    header("Location: login.php");
    exit();
}

$order_id = $_GET['order_id'];
$query = "SELECT o.id, o.order_date, pm.method, p.amount 
          FROM `order` o 
          JOIN payment p ON o.id = p.order_id 
          JOIN payment_method pm ON p.payment_method_id = pm.id
          WHERE o.id = '$order_id'";
$result = mysqli_query($koneksi, $query);

if (!$result) {
    die('Query Error: ' . mysqli_error($koneksi));
}

if ($row = mysqli_fetch_assoc($result)) {
    $kode_pembayaran = "PAY" . $row['id'] . strtoupper($row['method']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kode Pembayaran</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: rgba(0, 0, 0, 0.7);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
            text-align: center;
            width: 50%;
        }
        h2 {
            margin-bottom: 20px;
            font-size: 2.5em;
        }
        p {
            margin: 10px 0;
            font-size: 1.2em;
        }
        .btn-primary {
            background-color: #667eea;
            border-color: #667eea;
            padding: 10px 20px;
            font-size: 1.2em;
            border-radius: 5px;
        }
        .btn-primary:hover {
            background-color: #5a67d8;
            border-color: #5a67d8;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Kode Pembayaran</h2>
        <p>ID Pesanan: <?php echo $row['id']; ?></p>
        <p>Tanggal: <?php echo $row['order_date']; ?></p>
        <p>Metode Pembayaran: <?php echo $row['method']; ?></p>
        <p>Jumlah: <?php echo number_format($row['amount'], 0, ',', '.'); ?></p>
        <p>Kode Pembayaran: <strong><?php echo $kode_pembayaran; ?></strong></p>
        <a href="home_user.php" class="btn btn-primary mt-3">Kembali ke Halaman Utama</a>
    </div>
</body>
</html>
