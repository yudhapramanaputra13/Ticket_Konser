<?php
include 'koneksi.php';
session_start();

if (!isset($_SESSION['username']) || $_SESSION['level'] != 'Admin') {
    header("Location: login.php");
    exit();
}

$query = "SELECT * FROM concert";
$result = mysqli_query($koneksi, $query);

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action'])) {
    $name = $_POST['name'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    $price = $_POST['price'];
    $place = $_POST['place'];

    if ($_POST['action'] == 'add') {
        $query = "INSERT INTO concert (name, date, time, price, place) VALUES ('$name', '$date', '$time', '$price', '$place')";
        mysqli_query($koneksi, $query);
        echo "<script>alert('Konser berhasil ditambahkan'); window.location.href = 'home_admin.php';</script>";
    } elseif ($_POST['action'] == 'edit') {
        $id = $_POST['id'];
        $query = "UPDATE concert SET name='$name', date='$date', time='$time', price='$price', place='$place' WHERE id='$id'";
        mysqli_query($koneksi, $query);
        echo "<script>alert('Konser berhasil diubah'); window.location.href = 'home_admin.php';</script>";
    } elseif ($_POST['action'] == 'delete') {
        $id = $_POST['id'];
        $query = "DELETE FROM concert WHERE id='$id'";
        mysqli_query($koneksi, $query);
        echo "<script>alert('Konser berhasil dihapus'); window.location.href = 'home_admin.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Admin</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('image/admin.*'); /* Replace with your image path */
            background-size: cover;
            background-attachment: fixed;
            font-family: 'Roboto', sans-serif;
        }
        .container {
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 8px;
            margin-top: 30px;
        }
        .btn-primary {
            background-color: #009688;
            border-color: #009688;
        }
        .btn-primary:hover {
            background-color: #00796b;
            border-color: #00796b;
        }
        .btn-info {
            background-color: #004d40;
            border-color: #004d40;
        }
        .btn-info:hover {
            background-color: #003630;
            border-color: #003630;
        }
        .btn-warning {
            background-color: #ff9800;
            border-color: #ff9800;
        }
        .btn-warning:hover {
            background-color: #e68900;
            border-color: #e68900;
        }
        .btn-danger {
            background-color: #f44336;
            border-color: #f44336;
        }
        .btn-danger:hover {
            background-color: #d32f2f;
            border-color: #d32f2f;
        }
        .btn-success {
            background-color: #4caf50;
            border-color: #4caf50;
        }
        .btn-success:hover {
            background-color: #388e3c;
            border-color: #388e3c;
        }
        .table th, .table td {
            vertical-align: middle;
            text-align: center;
            border: 2px solid #dee2e6;
        }
        .table th {
            background-color: #009688;
            color: #ffffff;
        }
        .table-responsive {
            overflow-x: auto;
        }
        h2, h3 {
            color: #333333;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h2>Welcome, <?php echo $_SESSION['username']; ?></h2>
            <div>
                <a href="profile.php" class="btn btn-info">Lihat Profil</a>
                <a href="manage_orders.php" class="btn btn-warning">Kelola Pesanan</a>
                <a href="manage_payment_methods.php" class="btn btn-success">Kelola Metode Pembayaran</a>
                <a href="logout.php" class="btn btn-danger">Logout</a>
            </div>
        </div>
        <h3>Daftar Konser</h3>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Nama Konser</th>
                        <th>Tanggal</th>
                        <th>Waktu</th>
                        <th>Tempat</th>
                        <th>Harga</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = mysqli_fetch_assoc($result)) { ?>
                        <tr>
                            <td><?php echo $row['name']; ?></td>
                            <td><?php echo $row['date']; ?></td>
                            <td><?php echo $row['time']; ?></td>
                            <td><?php echo $row['place']; ?></td> <!-- Added Place Column -->
                            <td><?php echo $row['price']; ?></td>
                            <td>
                                <form method="post" action="" class="mb-2">
                                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                    <input type="hidden" name="action" value="edit">
                                    <div class="form-row align-items-center">
                                        <div class="col-auto">
                                            <input type="text" name="name" value="<?php echo $row['name']; ?>" class="form-control mb-2" required>
                                        </div>
                                        <div class="col-auto">
                                            <input type="date" name="date" value="<?php echo $row['date']; ?>" class="form-control mb-2" required>
                                        </div>
                                        <div class="col-auto">
                                            <input type="time" name="time" value="<?php echo $row['time']; ?>" class="form-control mb-2" required>
                                        </div>
                                        <div class="col-auto">
                                            <input type="text" name="place" value="<?php echo $row['place']; ?>" class="form-control mb-2" required>
                                        </div>
                                        <div class="col-auto">
                                            <input type="text" name="price" value="<?php echo $row['price']; ?>" class="form-control mb-2" required>
                                        </div>
                                        <div class="col-auto">
                                            <button type="submit" class="btn btn-warning mb-2">Edit</button>
                                        </div>
                                    </div>
                                </form>
                                <form method="post" action="">
                                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                    <input type="hidden" name="action" value="delete">
                                    <button type="submit" class="btn btn-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>

        <h3>Tambah Konser</h3>
        <form method="post" action="">
            <input type="hidden" name="action" value="add">
            <div class="form-group">
                <label for="name">Nama Konser:</label>
                <input type="text" id="name" name="name" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="date">Tanggal:</label>
                <input type="date" id="date" name="date" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="time">Waktu:</label>
                <input type="time" id="time" name="time" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="place">Tempat:</label>
                <input type="text" id="place" name="place" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="price">Harga:</label>
                <input type="text" id="price" name="price" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Tambah Konser</button>
        </form>
    </div>
</body>
</html>
