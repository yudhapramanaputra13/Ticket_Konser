<?php
include 'koneksi.php';
session_start();

if (!isset($_SESSION['username']) || $_SESSION['level'] != 'User') {
    header("Location: login.php");
    exit();
}

$username = $_SESSION['username'];
$query = "SELECT o.id, o.order_date, o.status, pm.method, p.amount 
          FROM `order` o 
          JOIN payment p ON o.id = p.order_id 
          JOIN payment_method pm ON p.payment_method_id = pm.id
          WHERE o.username = '$username'";
$result = mysqli_query($koneksi, $query);

if (!$result) {
    die('Query Error: ' . mysqli_error($koneksi));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Pembelian</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, rgba(58,123,213,1) 0%, rgba(58,213,173,1) 100%);
            font-family: 'Roboto', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            max-width: 1000px;
            width: 100%;
        }
        h2 {
            text-align: center;
            color: #3A7BD5;
            margin-bottom: 20px;
        }
        .table th, .table td {
            vertical-align: middle;
            text-align: center;
            border: 2px solid #dee2e6;
        }
        .table th {
            background-color: #3A7BD5;
            color: #ffffff;
        }
        .table tbody tr {
            background-color: #f9f9f9;
        }
        .table tbody tr:hover {
            background-color: #f1f1f1;
        }
        .btn-primary {
            background-color: #3A7BD5;
            border-color: #3A7BD5;
        }
        .btn-primary:hover {
            background-color: #2E5BA2;
            border-color: #2E5BA2;
        }
        .btn-secondary {
            background-color: #3AD5AD;
            border-color: #3AD5AD;
        }
        .btn-secondary:hover {
            background-color: #2EA283;
            border-color: #2EA283;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h2>Riwayat Pembelian</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID Pesanan</th>
                    <th>Tanggal</th>
                    <th>Status</th>
                    <th>Metode Pembayaran</th>
                    <th>Jumlah</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['order_date']; ?></td>
                        <td><?php echo $row['status']; ?></td>
                        <td><?php echo $row['method']; ?></td>
                        <td><?php echo $row['amount']; ?></td>
                        <td>
                            <a href="lihat_kode_pembayaran.php?order_id=<?php echo $row['id']; ?>" class="btn btn-primary">Lihat Kode Pembayaran</a>
                            <a href="cetak_eticket.php?order_id=<?php echo $row['id']; ?>" class="btn btn-secondary">Cetak E-Tiket</a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>
