<?php
include 'koneksi.php';
session_start();

if (!isset($_SESSION['username']) || $_SESSION['level'] != 'User') {
    header("Location: login.php");
    exit();
}

$query = "SELECT * FROM concert";
$result = mysqli_query($koneksi, $query);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $concert_id = $_POST['concert_id'];
    $username = $_SESSION['username'];

    // Check if the user already has a cart
    $query = "SELECT id FROM cart WHERE username = '$username'";
    $cart_result = mysqli_query($koneksi, $query);
    $cart = mysqli_fetch_assoc($cart_result);

    if ($cart) {
        $cart_id = $cart['id'];
    } else {
        // Create a new cart for the user if it doesn't exist
        $query = "INSERT INTO cart (username) VALUES ('$username')";
        mysqli_query($koneksi, $query);
        $cart_id = mysqli_insert_id($koneksi);
    }

    // Add concert to cart_item
    $query = "INSERT INTO cart_item (cart_id, concert_id, quantity) VALUES ('$cart_id', '$concert_id', 1)";
    mysqli_query($koneksi, $query);
    echo "<script>alert('Konser ditambahkan ke keranjang');</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home User</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('image/login.*'); /* URL gambar latar belakang */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        .btn-primary {
            background-color: #009688;
            border-color: #009688;
        }
        .btn-primary:hover {
            background-color: #00796b;
            border-color: #00796b;
        }
        .btn-info {
            background-color: #004d40;
            border-color: #004d40;
        }
        .btn-info:hover {
            background-color: #003630;
            border-color: #003630;
        }
        .btn-warning {
            background-color: #ff9800;
            border-color: #ff9800;
        }
        .btn-warning:hover {
            background-color: #e68900;
            border-color: #e68900;
        }
        .btn-danger {
            background-color: #f44336;
            border-color: #f44336;
        }
        .btn-danger:hover {
            background-color: #d32f2f;
            border-color: #d32f2f;
        }
        .btn-success {
            background-color: #4caf50;
            border-color: #4caf50;
        }
        .btn-success:hover {
            background-color: #388e3c;
            border-color: #388e3c;
        }
        .container {
            background-color: rgba(255, 255, 255, 0.8); /* Background putih semi transparan untuk konten */
            padding: 20px;
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h2>Welcome, <?php echo $_SESSION['username']; ?></h2>
            <div>
                <a href="profile.php" class="btn btn-info">Lihat Profil</a>
                <a href="cart.php" class="btn btn-warning">Keranjang</a>
                <a href="riwayat_pembelian.php" class="btn btn-success">Riwayat Pembelian</a>
                <a href="logout.php" class="btn btn-danger">Logout</a>
            </div>
        </div>
        <h3>Daftar Konser</h3>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Nama Konser</th>
                    <th>Tanggal</th>
                    <th>Waktu</th>
                    <th>Tempat</th>
                    <th>Harga</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?php echo $row['name']; ?></td>
                        <td><?php echo $row['date']; ?></td>
                        <td><?php echo $row['time']; ?></td>
                        <td><?php echo $row['place']; ?></td> <!-- Added Place Column -->
                        <td><?php echo $row['price']; ?></td>
                        <td>
                            <form method="post" action="">
                                <input type="hidden" name="concert_id" value="<?php echo $row['id']; ?>">
                                <button type="submit" class="btn btn-primary">Tambah ke Keranjang</button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>
