<?php
include 'koneksi.php';
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$username = $_SESSION['username'];

// Fetch cart items for the user
$query = "
    SELECT ci.id, ci.concert_id, c.name, c.price, ci.quantity
    FROM cart_item ci
    JOIN cart ct ON ci.cart_id = ct.id
    JOIN concert c ON ci.concert_id = c.id
    WHERE ct.username = '$username'
";
$result = mysqli_query($koneksi, $query);

// Initialize total price
$total_price = 0;

while ($row = mysqli_fetch_assoc($result)) {
    $item_total = $row['price'] * $row['quantity'];
    $total_price += $item_total;
}

// Fetch payment methods
$payment_query = "SELECT * FROM payment_method";
$payment_result = mysqli_query($koneksi, $payment_query);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $payment_method_id = $_POST['payment_method'];
    $order_date = date('Y-m-d');

    // Insert into order table
    $order_query = "INSERT INTO `order` (username, order_date, status) VALUES ('$username', '$order_date', 'Pending')";
    mysqli_query($koneksi, $order_query);
    $order_id = mysqli_insert_id($koneksi);

    // Insert into order_item table
    mysqli_data_seek($result, 0);
    while ($row = mysqli_fetch_assoc($result)) {
        $concert_id = $row['concert_id'];
        $quantity = $row['quantity'];
        $order_item_query = "INSERT INTO order_item (order_id, concert_id, quantity) VALUES ('$order_id', '$concert_id', '$quantity')";
        mysqli_query($koneksi, $order_item_query);
    }

    // Insert into payment table
    $payment_date = date('Y-m-d');
    $payment_query = "INSERT INTO payment (order_id, payment_method_id, payment_date, amount) VALUES ('$order_id', '$payment_method_id', '$payment_date', '$total_price')";
    mysqli_query($koneksi, $payment_query);

    // Generate payment code
    $kode_pembayaran = "PAY" . $order_id . strtoupper(mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT method FROM payment_method WHERE id = '$payment_method_id'"))['method']);

    // Clear the cart
    $clear_cart_query = "DELETE FROM cart_item WHERE cart_id = (SELECT id FROM cart WHERE username = '$username')";
    mysqli_query($koneksi, $clear_cart_query);

    // Redirect to kode_pembayaran.php with the payment code
    header("Location: kode_pembayaran.php?kode=$kode_pembayaran");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Checkout</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Nama Konser</th>
                    <th>Harga</th>
                    <th>Jumlah</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php
                mysqli_data_seek($result, 0);
                while ($row = mysqli_fetch_assoc($result)) { 
                    $item_total = $row['price'] * $row['quantity'];
                ?>
                    <tr>
                        <td><?php echo $row['name']; ?></td>
                        <td><?php echo $row['price']; ?></td>
                        <td><?php echo $row['quantity']; ?></td>
                        <td><?php echo number_format($item_total, 3); ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
        <div class="text-right">
            <h4>Total Harga: <?php echo number_format($total_price, 3); ?></h4>
        </div>
        <form method="post" action="">
            <div class="form-group">
                <label for="payment_method">Metode Pembayaran:</label>
                <select id="payment_method" name="payment_method" class="form-control" required>
                    <?php while($payment = mysqli_fetch_assoc($payment_result)) { ?>
                        <option value="<?php echo $payment['id']; ?>"><?php echo $payment['method']; ?></option>
                    <?php } ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Bayar</button>
        </form>
        <a href="cart.php" class="btn btn-secondary mt-3">Kembali ke Keranjang</a>
    </div>
</body>
</html>
