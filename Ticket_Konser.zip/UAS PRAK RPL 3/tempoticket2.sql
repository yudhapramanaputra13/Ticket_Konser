-- --------------------------------------------------------
-- Host:                         localhost
-- Server version:               8.0.30 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for tempoticket2
CREATE DATABASE IF NOT EXISTS `tempoticket2` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `tempoticket2`;

-- Dumping structure for table tempoticket2.cart
CREATE TABLE IF NOT EXISTS `cart` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK__register` (`username`),
  CONSTRAINT `FK__register` FOREIGN KEY (`username`) REFERENCES `register` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table tempoticket2.cart: ~0 rows (approximately)
INSERT INTO `cart` (`id`, `username`) VALUES
	(1, 'user'),
	(2, 'yudha');

-- Dumping structure for table tempoticket2.cart_item
CREATE TABLE IF NOT EXISTS `cart_item` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cart_id` int NOT NULL,
  `concert_id` int NOT NULL,
  `quantity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK__cart` (`cart_id`),
  KEY `FK__concert` (`concert_id`),
  CONSTRAINT `FK__cart` FOREIGN KEY (`cart_id`) REFERENCES `cart` (`id`),
  CONSTRAINT `FK__concert` FOREIGN KEY (`concert_id`) REFERENCES `concert` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table tempoticket2.cart_item: ~0 rows (approximately)
INSERT INTO `cart_item` (`id`, `cart_id`, `concert_id`, `quantity`) VALUES
	(34, 2, 1, 1);

-- Dumping structure for table tempoticket2.concert
CREATE TABLE IF NOT EXISTS `concert` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `price` decimal(10,3) NOT NULL,
  `place` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table tempoticket2.concert: ~5 rows (approximately)
INSERT INTO `concert` (`id`, `name`, `date`, `time`, `price`, `place`) VALUES
	(1, 'Konser A', '2024-08-17', '22:00:00', 100.000, 'Surabaya'),
	(2, 'Konser B', '2024-07-04', '06:11:00', 150.000, 'Surabaya'),
	(4, 'Konser C', '2024-07-06', '20:30:00', 100.000, 'Malang'),
	(8, 'Sheila On 7', '2024-06-29', '20:39:00', 300.000, 'Jakarta'),
	(10, 'Core Festival', '2024-06-22', '23:00:00', 200.000, 'Bandung'),
	(12, 'Uin Festival', '2024-06-22', '20:00:00', 300.000, 'Bandung');

-- Dumping structure for table tempoticket2.order
CREATE TABLE IF NOT EXISTS `order` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL DEFAULT '',
  `order_date` date NOT NULL,
  `status` enum('Pending','Confirmed','Cancelled') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK__register1` (`username`),
  CONSTRAINT `FK__register1` FOREIGN KEY (`username`) REFERENCES `register` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table tempoticket2.order: ~18 rows (approximately)
INSERT INTO `order` (`id`, `username`, `order_date`, `status`) VALUES
	(1, 'user', '2024-06-13', 'Pending'),
	(2, 'user', '2024-06-13', 'Pending'),
	(3, 'user', '2024-06-13', 'Pending'),
	(4, 'user', '2024-06-13', 'Pending'),
	(5, 'user', '2024-06-13', 'Pending'),
	(6, 'user', '2024-06-13', 'Confirmed'),
	(7, 'yudha', '2024-06-13', 'Pending'),
	(8, 'yudha', '2024-06-13', 'Pending'),
	(9, 'yudha', '2024-06-13', 'Pending'),
	(10, 'yudha', '2024-06-13', 'Pending'),
	(11, 'yudha', '2024-06-13', 'Pending'),
	(12, 'yudha', '2024-06-13', 'Pending'),
	(13, 'yudha', '2024-06-13', 'Pending'),
	(14, 'yudha', '2024-06-13', 'Pending'),
	(15, 'yudha', '2024-06-14', 'Pending'),
	(16, 'yudha', '2024-06-21', 'Pending'),
	(17, 'yudha', '2024-06-21', 'Pending'),
	(18, 'yudha', '2024-06-21', 'Pending'),
	(19, 'yudha', '2024-06-21', 'Pending');

-- Dumping structure for table tempoticket2.order_item
CREATE TABLE IF NOT EXISTS `order_item` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `concert_id` int NOT NULL,
  `quantity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK__order1` (`order_id`),
  KEY `FK__concert1` (`concert_id`),
  CONSTRAINT `FK__concert1` FOREIGN KEY (`concert_id`) REFERENCES `concert` (`id`),
  CONSTRAINT `FK__order1` FOREIGN KEY (`order_id`) REFERENCES `order` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table tempoticket2.order_item: ~17 rows (approximately)
INSERT INTO `order_item` (`id`, `order_id`, `concert_id`, `quantity`) VALUES
	(1, 6, 1, 2),
	(2, 6, 4, 2),
	(3, 7, 1, 1),
	(4, 7, 4, 1),
	(5, 8, 1, 1),
	(6, 9, 4, 1),
	(7, 10, 2, 1),
	(8, 11, 1, 1),
	(9, 13, 1, 1),
	(10, 14, 2, 1),
	(11, 15, 1, 1),
	(12, 16, 1, 1),
	(13, 16, 4, 1),
	(14, 16, 8, 1),
	(15, 17, 8, 1),
	(16, 18, 8, 1),
	(17, 19, 8, 2),
	(18, 19, 8, 1);

-- Dumping structure for table tempoticket2.payment
CREATE TABLE IF NOT EXISTS `payment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `payment_method_id` int NOT NULL,
  `payment_date` date NOT NULL,
  `amount` decimal(10,3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK__order` (`order_id`),
  KEY `FK__payment_method` (`payment_method_id`),
  CONSTRAINT `FK__order` FOREIGN KEY (`order_id`) REFERENCES `order` (`id`),
  CONSTRAINT `FK__payment_method` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_method` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table tempoticket2.payment: ~13 rows (approximately)
INSERT INTO `payment` (`id`, `order_id`, `payment_method_id`, `payment_date`, `amount`) VALUES
	(1, 6, 1, '2024-06-13', 300.000),
	(2, 7, 1, '2024-06-13', 150.000),
	(3, 8, 1, '2024-06-13', 50.000),
	(4, 9, 1, '2024-06-13', 100.000),
	(5, 10, 1, '2024-06-13', 150.000),
	(6, 11, 1, '2024-06-13', 50.000),
	(7, 12, 3, '2024-06-13', 0.000),
	(8, 13, 6, '2024-06-13', 50.000),
	(9, 14, 7, '2024-06-13', 150.000),
	(10, 15, 1, '2024-06-14', 50.000),
	(11, 16, 6, '2024-06-21', 450.000),
	(12, 17, 2, '2024-06-21', 300.000),
	(13, 18, 1, '2024-06-21', 300.000),
	(14, 19, 1, '2024-06-21', 900.000);

-- Dumping structure for table tempoticket2.payment_method
CREATE TABLE IF NOT EXISTS `payment_method` (
  `id` int NOT NULL AUTO_INCREMENT,
  `method` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table tempoticket2.payment_method: ~9 rows (approximately)
INSERT INTO `payment_method` (`id`, `method`) VALUES
	(1, 'BCA'),
	(2, 'MANDIRI'),
	(3, 'SHOPEEPAY'),
	(4, 'DANA'),
	(5, 'GOPAY'),
	(6, 'OVO'),
	(7, 'BRI'),
	(9, 'PAYTREN'),
	(11, 'SUPERBANK');

-- Dumping structure for table tempoticket2.register
CREATE TABLE IF NOT EXISTS `register` (
  `username` varchar(50) NOT NULL DEFAULT 'AUTO_INCREMENT',
  `password` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `level` enum('User','Admin') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table tempoticket2.register: ~2 rows (approximately)
INSERT INTO `register` (`username`, `password`, `level`, `email`) VALUES
	('admin', 'admin', 'Admin', 'syafrimaulanaa14@gmail.com'),
	('user', 'user', 'User', 'hellosyafrimaul@gmail.com'),
	('yudha', '123', 'User', 'yudhapramana1312@gmail.com');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
