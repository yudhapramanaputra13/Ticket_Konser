<?php
include 'koneksi.php';
session_start();

if (!isset($_SESSION['username']) || $_SESSION['level'] != 'Admin') {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action'])) {
    if ($_POST['action'] == 'add') {
        $method = $_POST['method'];
        
        $stmt = $koneksi->prepare("INSERT INTO payment_method (method) VALUES (?)");
        $stmt->bind_param("s", $method);
        $stmt->execute();
        $stmt->close();
        
        echo "<script>alert('Metode pembayaran berhasil ditambahkan'); window.location.href = 'manage_payment_methods.php';</script>";
    } elseif ($_POST['action'] == 'delete') {
        $id = $_POST['id'];

        $stmt = $koneksi->prepare("DELETE FROM payment_method WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();
        
        echo "<script>alert('Metode pembayaran berhasil dihapus'); window.location.href = 'manage_payment_methods.php';</script>";
    }
}

$query = "SELECT * FROM payment_method";
$result = mysqli_query($koneksi, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Metode Pembayaran</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, rgba(58,123,213,1) 0%, rgba(58,213,173,1) 100%);
            font-family: 'Roboto', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }
        .container {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            max-width: 800px;
            width: 100%;
        }
        .form-group label {
            font-weight: bold;
            color: #333;
        }
        .btn-primary {
            background-color: #3A7BD5;
            border-color: #3A7BD5;
        }
        .btn-primary:hover {
            background-color: #2E5BA2;
            border-color: #2E5BA2;
        }
        .btn-secondary {
            background-color: #3AD5AD;
            border-color: #3AD5AD;
        }
        .btn-secondary:hover {
            background-color: #2EA283;
            border-color: #2EA283;
        }
        .btn-danger {
            background-color: #dc3545;
            border-color: #dc3545;
            color: #fff;
        }
        .btn-danger:hover {
            background-color: #c82333;
            border-color: #bd2130;
            color: #fff;
        }
        .table th, .table td {
            vertical-align: middle;
            text-align: center;
            border: 2px solid #dee2e6;
        }
        .table th {
            background-color: #3A7BD5;
            color: #fff;
        }
        h2, h3 {
            color: #3A7BD5;
            font-weight: bold;
        }
        label {
            color: #333;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h2>Kelola Metode Pembayaran</h2>
            <a href="home_admin.php" class="btn btn-secondary">Kembali ke Home Admin</a>
        </div>
        <h3>Daftar Metode Pembayaran</h3>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Metode Pembayaran</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = mysqli_fetch_assoc($result)) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['method']); ?></td>
                            <td>
                                <form method="post" action="">
                                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                    <input type="hidden" name="action" value="delete">
                                    <button type="submit" class="btn btn-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
        <h3>Tambah Metode Pembayaran</h3>
        <form method="post" action="">
            <input type="hidden" name="action" value="add">
            <div class="form-group">
                <label for="method">Metode Pembayaran:</label>
                <input type="text" id="method" name="method" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Tambah Metode Pembayaran</button>
        </form>
    </div>
</body>
</html>
