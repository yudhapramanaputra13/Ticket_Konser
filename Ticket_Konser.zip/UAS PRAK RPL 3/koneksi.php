<?php

$host = "localhost";
$user = "root";
$password = "";
$dbname = "tempoticket2";

$koneksi = mysqli_connect($host, $user, $password, $dbname);