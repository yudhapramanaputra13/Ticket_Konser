<?php
session_start();
include('koneksi.php');

if (!isset($_SESSION['username']) || $_SESSION['level'] != 'User') {
    header("Location: login.php");
    exit();
}

$order_id = $_GET['order_id'];
$query = "SELECT o.id, o.order_date, pm.method, p.amount, c.name, c.date, c.time 
          FROM `order` o 
          JOIN order_item oi ON o.id = oi.order_id 
          JOIN concert c ON oi.concert_id = c.id 
          JOIN payment p ON o.id = p.order_id 
          JOIN payment_method pm ON p.payment_method_id = pm.id
          WHERE o.id = '$order_id'";
$result = mysqli_query($koneksi, $query);

if (!$result) {
    die('Query Error: ' . mysqli_error($koneksi));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Ticket</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea, #764ba2);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: #2d2f3e;
            color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            max-width: 600px;
            width: 100%;
        }
        h2 {
            text-align: center;
            color: #ff6f61;
            margin-bottom: 20px;
        }
        .ticket-details p {
            margin: 5px 0;
        }
        .button-container {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }
        .btn-primary {
            background-color: #ff6f61;
            border-color: #ff6f61;
        }
        .btn-primary:hover {
            background-color: #e65a50;
            border-color: #e65a50;
        }
        .btn-warning {
            background-color: #ffcc00;
            border-color: #ffcc00;
            color: #000;
        }
        .btn-warning:hover {
            background-color: #e6b800;
            border-color: #e6b800;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center mb-4">E-Ticket</h2>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <div class="ticket-details">
                <p><strong>ID Pesanan:</strong> <?php echo $row['id']; ?></p>
                <p><strong>Tanggal Pesanan:</strong> <?php echo $row['order_date']; ?></p>
                <p><strong>Metode Pembayaran:</strong> <?php echo $row['method']; ?></p>
                <p><strong>Jumlah:</strong> <?php echo $row['amount']; ?></p>
                <p><strong>Nama Konser:</strong> <?php echo $row['name']; ?></p>
                <p><strong>Tanggal Konser:</strong> <?php echo $row['date']; ?></p>
                <p><strong>Waktu Konser:</strong> <?php echo $row['time']; ?></p>
                <div class="button-container">
                    <button onclick="window.print()" class="btn btn-primary">Cetak E-Ticket</button>
                </div>
                <hr>
            </div>
        <?php } ?>
        <div class="button-container">
            <a href="home_user.php" class="btn btn-warning">Kembali ke Halaman Utama</a>
        </div>
    </div>
</body>
</html>
