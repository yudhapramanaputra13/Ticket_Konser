<?php
include 'koneksi.php';
session_start(); 

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$username = $_SESSION['username'];
$query = "SELECT * FROM register WHERE username='$username'";
$result = mysqli_query($koneksi, $query);
$row = mysqli_fetch_assoc($result);

if (!$row) {
    echo "<script>alert('User tidak ditemukan');</script>";
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_username = mysqli_real_escape_string($koneksi, $_POST['username']);
    $new_email = mysqli_real_escape_string($koneksi, $_POST['email']);
    $new_password = mysqli_real_escape_string($koneksi, $_POST['password']);

    $update_query = "UPDATE register SET username='$new_username', email='$new_email', password='$new_password' WHERE username='$username'";
    
    if (mysqli_query($koneksi, $update_query)) {
        $_SESSION['username'] = $new_username; // Update session username
        echo "<script>alert('Profil berhasil diperbarui');</script>";
    } else {
        echo "<script>alert('Profil gagal diperbarui');</script>";
    }
}

// Tentukan URL home berdasarkan level pengguna
$home_url = $_SESSION['level'] == 'Admin' ? 'home_admin.php' : 'home_user.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, rgba(58,123,213,1) 0%, rgba(58,213,173,1) 100%);
            font-family: 'Roboto', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            max-width: 600px;
            width: 100%;
        }
        .form-group label {
            font-weight: bold;
            color: #333;
        }
        .btn-primary {
            background-color: #3A7BD5;
            border-color: #3A7BD5;
        }
        .btn-primary:hover {
            background-color: #2E5BA2;
            border-color: #2E5BA2;
        }
        .btn-secondary {
            background-color: #3AD5AD;
            border-color: #3AD5AD;
        }
        .btn-secondary:hover {
            background-color: #2EA283;
            border-color: #2EA283;
        }
        h2 {
            color: #3A7BD5;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="text-center">Profil Pengguna</h2>
        <form method="post" action="">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" class="form-control" value="<?php echo $row['username']; ?>" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" class="form-control" value="<?php echo $row['email']; ?>" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" class="form-control" value="<?php echo $row['password']; ?>" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Update Profil</button>
        </form>
        <a href="<?php echo $home_url; ?>" class="btn btn-secondary btn-block mt-3">Kembali ke Home</a>
    </div>
</body>
</html>
