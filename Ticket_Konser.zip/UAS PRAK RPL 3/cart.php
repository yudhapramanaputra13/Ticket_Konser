<?php
include 'koneksi.php';
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$username = $_SESSION['username'];

// Fetch cart items for the user
$query = "
    SELECT ci.id, c.name, c.price, ci.quantity
    FROM cart_item ci
    JOIN cart ct ON ci.cart_id = ct.id
    JOIN concert c ON ci.concert_id = c.id
    WHERE ct.username = '$username'
";
$result = mysqli_query($koneksi, $query);

// Initialize total price
$total_price = 0;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['delete'])) {
        // Delete item from cart
        $item_id = $_POST['item_id'];
        $delete_query = "DELETE FROM cart_item WHERE id='$item_id'";
        mysqli_query($koneksi, $delete_query);
        header("Location: cart.php"); // Refresh page
    } elseif (isset($_POST['update'])) {
        // Update item quantity in cart
        $item_id = $_POST['item_id'];
        $new_quantity = $_POST['quantity'];
        $update_query = "UPDATE cart_item SET quantity='$new_quantity' WHERE id='$item_id'";
        mysqli_query($koneksi, $update_query);
        header("Location: cart.php"); // Refresh page
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, rgba(58,123,213,1) 0%, rgba(58,213,173,1) 100%);
            font-family: 'Roboto', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            max-width: 800px;
            width: 100%;
        }
        .form-group label {
            font-weight: bold;
            color: #333;
        }
        .btn-primary {
            background-color: #3A7BD5;
            border-color: #3A7BD5;
        }
        .btn-primary:hover {
            background-color: #2E5BA2;
            border-color: #2E5BA2;
        }
        .btn-secondary {
            background-color: #3AD5AD;
            border-color: #3AD5AD;
        }
        .btn-secondary:hover {
            background-color: #2EA283;
            border-color: #2EA283;
        }
        h2 {
            color: #3A7BD5;
            font-weight: bold;
        }
        .table thead th {
            background-color: #3A7BD5;
            color: #ffffff;
        }
        .table tbody tr {
            background-color: #f9f9f9;
        }
        .table tbody tr:hover {
            background-color: #f1f1f1;
        }
        .form-control {
            background-color: #fff;
            border: 1px solid #ced4da;
            color: #495057;
        }
        .form-control:focus {
            background-color: #fff;
            border-color: #80bdff;
            outline: 0;
            box-shadow: 0 0 0 0.2rem rgba(0,123,255,.25);
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center mb-4">Keranjang Belanja</h2>
        <table class="table table-bordered">
            <thead class="text-center">
                <tr>
                    <th>Nama Konser</th>
                    <th>Harga</th>
                    <th>Jumlah</th>
                    <th>Total</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = mysqli_fetch_assoc($result)) { 
                    $item_total = $row['price'] * $row['quantity'];
                    $total_price += $item_total;
                ?>
                    <tr class="text-center">
                        <td><?php echo $row['name']; ?></td>
                        <td><?php echo $row['price']; ?></td>
                        <td>
                            <form method="post" action="">
                                <input type="hidden" name="item_id" value="<?php echo $row['id']; ?>">
                                <input type="number" name="quantity" value="<?php echo $row['quantity']; ?>" min="1" class="form-control d-inline-block" style="width: 80px;">
                                <button type="submit" name="update" class="btn btn-warning btn-sm mt-2">Update</button>
                            </form>
                        </td>
                        <td><?php echo number_format($item_total, 3); ?></td>
                        <td>
                            <form method="post" action="">
                                <input type="hidden" name="item_id" value="<?php echo $row['id']; ?>">
                                <button type="submit" name="delete" class="btn btn-danger btn-sm">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
        <div class="text-right">
            <h4>Total Harga: <?php echo number_format($total_price, 3); ?></h4>
        </div>
        <div class="text-center mt-4">
            <a href="home_user.php" class="btn btn-secondary">Kembali ke Home</a>
            <a href="checkout.php" class="btn btn-primary">Checkout</a>
        </div>
    </div>
</body>
</html>
