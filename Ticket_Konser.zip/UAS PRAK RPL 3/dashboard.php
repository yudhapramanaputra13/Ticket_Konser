<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tempo Ticket - Ticketing</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body, html {
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
            font-family: 'Roboto', sans-serif;
           
        }
        .header {
            background-color: #009688;
            padding: 20px;
            color: white;
            text-align: left;
            font-size: 24px;
            font-weight: bold;
            position: absolute;
            top: 0;
            width: 100%;
            z-index: 2;
            display: flex;
            align-items: center;
            box-sizing: border-box;
        }
        .register, .login {
            background-color: #004d40;
            padding: 8px 12px;
            border-radius: 4px;
            margin-left: 10px;
            white-space: nowrap;
            border: none;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }
        .login {
            margin-left: auto;
        }
        .register:hover, .login:hover {
            background-color: #00796b;
        }
        .main {
            width: 100%;
            height: 100%;
            position: absolute;
            top: 0;
            left: 0;
            z-index: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: hidden;
        }
        .main video {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
    </style>
</head>
<body>
    <div class="header">
        Tempo Ticket
        <button class="login" onclick="window.location.href='login.php'">Login</button>
        <button class="register" onclick="window.location.href='register.php'">Register</button>
    </div>
    <div class="main">
        <video autoplay muted loop>
            <source src="https://sunset.kebunraya.id/videos/video-sunset.mp4" type="video/mp4">
            Your browser does not support the video tag.
        </video>
    </div>
</body>
</html>